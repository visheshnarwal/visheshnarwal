function viewproject(projectNumber)
{
    alert('viewing details for project'+ projectNumber);
}